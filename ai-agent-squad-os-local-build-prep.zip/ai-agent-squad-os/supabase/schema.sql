-- Squad OS starter schema for Supabase/PostgreSQL.
-- Apply only after reviewing the schema for your product and tenant model.
create extension if not exists pgcrypto;

create table if not exists public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.workspace_members (
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','admin','member','viewer')),
  created_at timestamptz not null default now(),
  primary key (workspace_id, user_id)
);

create table if not exists public.agents (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  slug text not null,
  name text not null,
  role text not null,
  boss_name text not null,
  status text not null default 'idle' check (status in ('idle','working','review_needed','ready','paused','error')),
  configuration jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (workspace_id, slug)
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  title text not null,
  objective text not null,
  status text not null default 'draft' check (status in ('draft','research','evaluation','approved','executing','completed','blocked','cancelled')),
  owner_user_id uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.evaluations (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  project_id uuid not null references public.projects(id) on delete cascade,
  agent_id uuid not null references public.agents(id) on delete cascade,
  level integer not null check (level between 1 and 20),
  status text not null default 'pending' check (status in ('pending','needs_correction','passed','failed','blocked')),
  score numeric(5,2) check (score between 0 and 100),
  criteria jsonb not null default '{}'::jsonb,
  findings jsonb not null default '[]'::jsonb,
  response text,
  evaluated_by text,
  evaluated_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.sources (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  project_id uuid references public.projects(id) on delete cascade,
  url text not null,
  title text,
  publisher text,
  retrieved_at timestamptz not null default now(),
  published_at timestamptz,
  verification_status text not null default 'unverified' check (verification_status in ('unverified','verified','rejected','stale')),
  claims jsonb not null default '[]'::jsonb,
  content_hash text
);

create table if not exists public.opportunities (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  project_id uuid references public.projects(id) on delete set null,
  title text not null,
  category text not null,
  estimated_low numeric(14,2),
  estimated_high numeric(14,2),
  currency text not null default 'USD',
  confidence numeric(5,2) check (confidence between 0 and 100),
  risk_level text not null default 'medium' check (risk_level in ('low','medium','high')),
  assumptions jsonb not null default '[]'::jsonb,
  status text not null default 'discovered' check (status in ('discovered','researching','validated','approved','rejected','executing','won','lost')),
  created_at timestamptz not null default now()
);

create table if not exists public.partners (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  company_name text not null,
  contact_name text,
  contact_email text,
  relationship_type text not null default 'prospect',
  status text not null default 'lead',
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.deals (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  partner_id uuid references public.partners(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  title text not null,
  stage text not null default 'draft' check (stage in ('draft','internal_review','approved_to_send','negotiation','legal_review','signature_pending','won','lost','cancelled')),
  value numeric(14,2),
  currency text not null default 'USD',
  contract_version integer not null default 1,
  document_url text,
  requires_human_approval boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.approvals (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  action_type text not null,
  resource_type text not null,
  resource_id uuid not null,
  requested_by text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected','expired','cancelled')),
  reviewed_by uuid references auth.users(id) on delete set null,
  reason text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

create table if not exists public.audit_log (
  id bigint generated always as identity primary key,
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  actor_type text not null check (actor_type in ('user','agent','system','integration')),
  actor_id text,
  action text not null,
  resource_type text,
  resource_id text,
  outcome text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists projects_workspace_created_idx on public.projects(workspace_id, created_at desc);
create index if not exists evaluations_project_level_idx on public.evaluations(project_id, level, created_at desc);
create index if not exists sources_project_retrieved_idx on public.sources(project_id, retrieved_at desc);
create index if not exists opportunities_workspace_status_idx on public.opportunities(workspace_id, status);
create index if not exists deals_workspace_stage_idx on public.deals(workspace_id, stage);
create index if not exists audit_workspace_created_idx on public.audit_log(workspace_id, created_at desc);

-- Enable RLS. Add carefully reviewed membership-based policies before exposing tables.
alter table public.workspaces enable row level security;
alter table public.workspace_members enable row level security;
alter table public.agents enable row level security;
alter table public.projects enable row level security;
alter table public.evaluations enable row level security;
alter table public.sources enable row level security;
alter table public.opportunities enable row level security;
alter table public.partners enable row level security;
alter table public.deals enable row level security;
alter table public.approvals enable row level security;
alter table public.audit_log enable row level security;

-- Intentionally no permissive client policies are created in this starter.
-- The app must add membership-based policies or use trusted server routes that
-- authenticate the user, verify workspace membership, and write audit records.
-- Do not expose the service-role key in browser code.
