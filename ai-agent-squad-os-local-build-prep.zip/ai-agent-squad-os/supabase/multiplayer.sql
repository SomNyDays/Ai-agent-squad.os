-- Multiplayer extension for Squad OS. Review and test in a development project.
create table if not exists public.game_rooms (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  code text not null unique,
  title text not null,
  host_user_id uuid not null references auth.users(id),
  status text not null default 'lobby' check (status in ('lobby','active','paused','completed','cancelled')),
  phase text not null default 'lobby',
  current_round integer not null default 1 check (current_round > 0),
  max_rounds integer not null default 5 check (max_rounds between 1 and 20),
  max_players integer not null default 8 check (max_players between 2 and 32),
  objective text not null,
  objective_type text not null,
  rules_version text not null default '1.0.0',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.game_players (
  room_id uuid not null references public.game_rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null,
  role text not null default 'player' check (role in ('owner','player','spectator')),
  team_id text not null default 'alpha',
  ready boolean not null default false,
  connected_at timestamptz,
  last_seen_at timestamptz,
  score integer not null default 0,
  reputation integer not null default 0,
  joined_at timestamptz not null default now(),
  primary key (room_id, user_id)
);

create table if not exists public.game_events (
  id bigint generated always as identity primary key,
  room_id uuid not null references public.game_rooms(id) on delete cascade,
  sequence bigint not null,
  event_type text not null,
  actor_user_id uuid references auth.users(id) on delete set null,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(room_id, sequence)
);

create table if not exists public.game_actions (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.game_rooms(id) on delete cascade,
  actor_user_id uuid not null references auth.users(id) on delete cascade,
  action_type text not null,
  payload jsonb not null default '{}'::jsonb,
  idempotency_key text not null,
  status text not null default 'accepted' check (status in ('accepted','rejected','processed')),
  created_at timestamptz not null default now(),
  unique(room_id, actor_user_id, idempotency_key)
);

create table if not exists public.game_votes (
  room_id uuid not null references public.game_rooms(id) on delete cascade,
  round integer not null,
  voter_user_id uuid not null references auth.users(id) on delete cascade,
  target_id text not null,
  vote text not null check (vote in ('upvote','challenge','abstain')),
  created_at timestamptz not null default now(),
  primary key(room_id, round, voter_user_id, target_id)
);

create table if not exists public.game_scores (
  room_id uuid not null references public.game_rooms(id) on delete cascade,
  round integer not null,
  user_id uuid not null references auth.users(id) on delete cascade,
  score_delta integer not null,
  reason text not null,
  evidence jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  primary key(room_id, round, user_id, reason)
);

create index if not exists game_rooms_workspace_status_idx on public.game_rooms(workspace_id, status);
create index if not exists game_players_user_idx on public.game_players(user_id, last_seen_at desc);
create index if not exists game_events_room_sequence_idx on public.game_events(room_id, sequence);
create index if not exists game_actions_room_created_idx on public.game_actions(room_id, created_at desc);

alter table public.game_rooms enable row level security;
alter table public.game_players enable row level security;
alter table public.game_events enable row level security;
alter table public.game_actions enable row level security;
alter table public.game_votes enable row level security;
alter table public.game_scores enable row level security;

-- No permissive policies are added here. Before enabling multiplayer, implement
-- authenticated room membership checks, room-code rate limiting, owner-only
-- room settings, server-validated phase/turn transitions, and private payload
-- policies. Broadcast only safe event summaries. Never trust client scores.
