-- Apply AFTER schema.sql and multiplayer.sql. These policies are intentionally
-- read-only for clients; mutations go through authenticated server routes/RPCs.
create or replace function public.is_game_room_member(target_room uuid)
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.game_players gp
    where gp.room_id = target_room and gp.user_id = auth.uid()
  );
$$;

revoke all on function public.is_game_room_member(uuid) from public;
grant execute on function public.is_game_room_member(uuid) to authenticated;

create policy "room members can read room" on public.game_rooms
for select to authenticated using (public.is_game_room_member(id));

create policy "players can read room roster" on public.game_players
for select to authenticated using (public.is_game_room_member(room_id));

create policy "room members can read game events" on public.game_events
for select to authenticated using (public.is_game_room_member(room_id));

create policy "players can read game actions" on public.game_actions
for select to authenticated using (public.is_game_room_member(room_id));

create policy "room members can read votes" on public.game_votes
for select to authenticated using (public.is_game_room_member(room_id));

create policy "room members can read scores" on public.game_scores
for select to authenticated using (public.is_game_room_member(room_id));

-- The security-definer membership function must only answer membership; do not
-- grant client write access to score, phase, event sequence, or room capacity.
-- Test policies with two unrelated authenticated users before production.
