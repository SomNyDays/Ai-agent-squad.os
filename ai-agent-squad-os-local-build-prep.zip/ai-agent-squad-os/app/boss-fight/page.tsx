"use client";

import Link from "next/link";
import Image from "next/image";
import { useState } from "react";
import { ArrowLeft, Shield, Swords, Zap, RotateCcw, Trophy } from "lucide-react";

const moves = [
  { id: "scan", name: "SCAN PATTERN", detail: "Analyze the boss's next move", cost: 10, damage: 0 },
  { id: "dash", name: "PHASE DASH", detail: "Evade the incoming strike", cost: 20, damage: 8 },
  { id: "counter", name: "LIGHTBLADE COUNTER", detail: "Strike during the recovery window", cost: 30, damage: 18 },
  { id: "overload", name: "GRID OVERLOAD", detail: "High-risk finisher", cost: 45, damage: 32 },
];

export default function BossFightPage() {
  const [playerHP, setPlayerHP] = useState(100);
  const [bossHP, setBossHP] = useState(10000);
  const [energy, setEnergy] = useState(60);
  const [round, setRound] = useState(1);
  const [netIncome, setNetIncome] = useState(0);
  const [revenue, setRevenue] = useState(0);
  const [sales, setSales] = useState(0);
  const [outputs, setOutputs] = useState(0);
  const [impactVerified, setImpactVerified] = useState(false);
  const baseImpactPoints = Math.floor(netIncome / 100) + Math.floor(revenue / 250) + Math.floor(sales) * 5 + Math.floor(outputs) * 3;
  const impactPoints = impactVerified ? baseImpactPoints * 100 : 0;
  const [log, setLog] = useState<string[]>(["Arena initialized. The Overlord is studying your movement.", "Boss shields online — scan before committing energy."]);
  const won = bossHP <= 0;
  const lost = playerHP <= 0;

  function act(move: typeof moves[number]) {
    if (won || lost || energy < move.cost) return;
    let nextBoss = Math.max(0, bossHP - move.damage);
    let nextPlayer = playerHP;
    let message = "";
    if (move.id === "scan") {
      message = "Pattern scan complete: the Overlord's right flank is exposed. Next counter costs less energy.";
    } else if (move.id === "dash") {
      nextPlayer = Math.max(0, playerHP - 4);
      message = "You phase-dash through the red strike and land a glancing hit.";
    } else if (move.id === "counter") {
      nextPlayer = Math.max(0, playerHP - 8);
      message = "Blue lightblade connects. The boss staggers, but retaliates.";
    } else {
      nextPlayer = Math.max(0, playerHP - 16);
      message = "GRID OVERLOAD! The arena flashes as your finisher crashes through the boss shield.";
    }
    const newRound = round + 1;
    setBossHP(nextBoss); setPlayerHP(nextPlayer); setEnergy(Math.min(100, energy - move.cost + 12)); setRound(newRound);
    setLog(old => [message, ...old].slice(0, 5));
  }

  function applyImpact() {
    if (!impactVerified || impactPoints <= 0 || won || lost) return;
    const damage = Math.min(bossHP, impactPoints);
    setBossHP(Math.max(0, bossHP - damage));
    setLog(old => [`Verified business impact dealt ${damage.toLocaleString()} boss damage (${impactPoints.toLocaleString()} damage points at 100× scoring).`, ...old].slice(0, 5));
    setImpactVerified(false);
  }

  function reset() {
    setPlayerHP(100); setBossHP(10000); setEnergy(60); setRound(1);
    setNetIncome(0); setRevenue(0); setSales(0); setOutputs(0); setImpactVerified(false);
    setLog(["Arena initialized. The Overlord is studying your movement.", "Boss shields online — scan before committing energy."]);
  }

  return <main className="min-h-screen bg-[#050812] text-slate-100">
    <div className="mx-auto max-w-7xl px-4 py-5 md:px-8">
      <div className="mb-5 flex items-center justify-between">
        <Link href="/" className="inline-flex items-center gap-2 text-sm text-slate-400 hover:text-white"><ArrowLeft size={16}/> Squad OS</Link>
        <span className="rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-1 text-xs tracking-widest text-cyan-200">BOSS GAUNTLET / LEVEL 05</span>
      </div>
      <header className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div><p className="text-xs font-bold uppercase tracking-[.3em] text-red-300">Live combat simulation</p><h1 className="mt-2 text-3xl font-black tracking-tight md:text-5xl">THE OVERLORD</h1><p className="mt-2 text-slate-400">Neon arena • Tactical boss evaluation • Turn-based demo</p></div>
        <div className="flex gap-3"><div className="rounded-xl border border-white/10 bg-white/[.04] px-4 py-3"><p className="text-xs text-slate-500">ROUND</p><p className="text-2xl font-bold">{round}</p></div><div className="rounded-xl border border-white/10 bg-white/[.04] px-4 py-3"><p className="text-xs text-slate-500">ENERGY</p><p className="text-2xl font-bold text-cyan-200">{energy}%</p></div></div>
      </header>
      <section className="relative overflow-hidden rounded-3xl border border-cyan-300/20 bg-black shadow-[0_0_60px_rgba(0,180,255,.12)]">
        <div className="relative h-[300px] md:h-[520px]">
          <Image src="/boss-arena.png" alt="Blue armored fighter facing a red energy-armored boss in a neon arena" fill priority className="object-cover object-center"/>
          <div className="absolute inset-0 bg-gradient-to-t from-[#050812] via-transparent to-black/25"/>
          <div className="absolute left-4 right-4 top-4 grid gap-3 md:left-7 md:right-7 md:top-7 md:grid-cols-2">
            <div className="rounded-xl border border-cyan-300/30 bg-black/65 p-3 backdrop-blur"><div className="mb-2 flex items-center gap-2 text-sm font-semibold text-cyan-200"><Shield size={16}/> YOUR SQUAD</div><div className="h-3 overflow-hidden rounded-full bg-slate-800"><div className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all" style={{width:`${playerHP}%`}}/></div><p className="mt-1 text-xs text-slate-300">Integrity {playerHP}%</p></div>
            <div className="rounded-xl border border-red-300/30 bg-black/65 p-3 backdrop-blur"><div className="mb-2 flex items-center gap-2 text-sm font-semibold text-red-200"><Zap size={16}/> AI OVERLORD</div><div className="h-3 overflow-hidden rounded-full bg-slate-800"><div className="h-full bg-gradient-to-r from-red-600 to-rose-400 transition-all" style={{width:`${bossHP}%`}}/></div><p className="mt-1 text-xs text-slate-300">Boss shield {bossHP}%</p></div>
          </div>
          <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-end justify-between gap-3 md:bottom-7 md:left-7 md:right-7"><div><p className="text-xs uppercase tracking-[.25em] text-cyan-200">The Neon Frontier</p><h2 className="mt-1 text-xl font-bold md:text-3xl">{won ? "BOSS DEFEATED" : lost ? "SQUAD DOWN" : "Break the boss's pattern"}</h2><p className="mt-1 max-w-xl text-sm text-slate-300">Read the pattern, manage energy, and strike during openings. This is a playable UI prototype, not networked combat.</p></div>{(won||lost)&&<div className="rounded-xl border border-yellow-300/30 bg-black/70 px-4 py-3 text-yellow-100"><Trophy className="inline mr-2" size={18}/>{won?"Victory earned":"Retry the gauntlet"}</div>}</div>
        </div>
      </section>
      <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_320px]">
        <section className="rounded-2xl border border-white/10 bg-white/[.035] p-4 md:p-5">
          <div className="mb-4 flex items-center gap-2"><Swords className="text-cyan-200"/><h2 className="text-lg font-bold">Choose your move</h2></div>
          <div className="grid gap-3 sm:grid-cols-2">
            {moves.map(m=><button key={m.id} onClick={()=>act(m)} disabled={won||lost||energy<m.cost} className="group rounded-2xl border border-cyan-300/15 bg-[#08111f] p-4 text-left transition hover:border-cyan-300/60 hover:bg-cyan-300/[.06] disabled:cursor-not-allowed disabled:opacity-40"><div className="flex items-start justify-between gap-2"><h3 className="font-bold tracking-wide">{m.name}</h3><span className="rounded-md bg-cyan-300/10 px-2 py-1 text-xs text-cyan-200">{m.cost} EN</span></div><p className="mt-2 text-sm text-slate-400">{m.detail}</p><div className="mt-4 flex items-center justify-between text-xs"><span className="text-slate-500">Impact</span><span className={m.damage>20?"text-red-300":"text-cyan-200"}>{m.damage ? `${m.damage} damage` : "Reveals opening"}</span></div></button>)}
          </div>
          <button onClick={reset} className="mt-4 inline-flex items-center gap-2 rounded-lg border border-white/10 px-4 py-2 text-sm text-slate-300 hover:bg-white/5"><RotateCcw size={15}/> Restart simulation</button>
        </section>
        <section className="rounded-2xl border border-emerald-300/20 bg-emerald-300/[.035] p-4 md:p-5 lg:col-span-2">
          <div className="mb-2 flex flex-wrap items-center justify-between gap-2"><div><p className="text-xs font-bold uppercase tracking-[.2em] text-emerald-200">Business impact → boss damage</p><h2 className="mt-1 text-lg font-bold">100× impact scoring — every base point deals 100 damage</h2></div><div className="rounded-lg bg-emerald-300/10 px-3 py-2 text-sm text-emerald-100">{impactPoints.toLocaleString()} damage points</div></div>
          <p className="mb-4 text-sm text-slate-400">Enter results from the project. Unverified or simulated numbers award zero damage until verified. Avoid counting the same transaction twice.</p>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <label className="text-xs text-slate-400">Net income (USD)<input type="number" min="0" value={netIncome} onChange={e=>setNetIncome(Math.max(0, Number(e.target.value)||0))} className="mt-1 w-full rounded-lg border border-white/10 bg-black/30 p-3 text-base text-white" /></label>
            <label className="text-xs text-slate-400">Revenue (USD)<input type="number" min="0" value={revenue} onChange={e=>setRevenue(Math.max(0, Number(e.target.value)||0))} className="mt-1 w-full rounded-lg border border-white/10 bg-black/30 p-3 text-base text-white" /></label>
            <label className="text-xs text-slate-400">Sales count<input type="number" min="0" step="1" value={sales} onChange={e=>setSales(Math.max(0, Number(e.target.value)||0))} className="mt-1 w-full rounded-lg border border-white/10 bg-black/30 p-3 text-base text-white" /></label>
            <label className="text-xs text-slate-400">Accepted outputs / deliverables<input type="number" min="0" step="1" value={outputs} onChange={e=>setOutputs(Math.max(0, Number(e.target.value)||0))} className="mt-1 w-full rounded-lg border border-white/10 bg-black/30 p-3 text-base text-white" /></label>
          </div>
          <label className="mt-4 flex items-center gap-2 text-sm text-slate-300"><input type="checkbox" checked={impactVerified} onChange={e=>setImpactVerified(e.target.checked)} /> I have verified these figures against evidence (receipts, analytics, invoices, or accepted deliverables).</label>
          <button onClick={applyImpact} disabled={!impactVerified||impactPoints<=0||won||lost} className="mt-3 rounded-lg bg-emerald-300 px-4 py-2 font-bold text-slate-950 disabled:cursor-not-allowed disabled:opacity-40">Apply {impactPoints.toLocaleString()} impact damage</button>
          <p className="mt-3 text-xs leading-5 text-slate-500">100× multiplier: every $100 net income = 100 damage points; every $250 revenue = 100 damage points; each sale = 500 damage points; each accepted output = 300 damage points. Boss HP is scaled to 10,000 for the larger scoring range. This is a tunable game-balance rule, not an accounting standard.</p>
        </section>
        <aside className="rounded-2xl border border-white/10 bg-white/[.035] p-5"><h2 className="mb-4 text-lg font-bold">Combat log</h2><div className="space-y-3">{log.map((line,i)=><div key={`${line}-${i}`} className="border-l-2 border-cyan-400/50 pl-3"><p className="text-[10px] uppercase tracking-widest text-slate-600">{i===0?"Latest event":`Event ${i+1}`}</p><p className="mt-1 text-sm leading-5 text-slate-300">{line}</p></div>)}</div><div className="mt-6 rounded-xl border border-amber-300/15 bg-amber-300/[.04] p-3 text-xs leading-5 text-amber-100/80">Boss fights are the game’s evaluation metaphor: the real boss rubric still checks evidence, safety, viability, and corrections rather than rewarding combat alone.</div></aside>
      </div>
    </div>
  </main>;
}
