import { NextResponse } from "next/server";
import { z } from "zod";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

const CreateRoom = z.object({
  title: z.string().trim().min(3).max(80),
  objective: z.string().trim().min(10).max(1000),
  objectiveType: z.enum(["research","marketing","sponsorship","partnership","product","resale","licensing"]).default("research"),
  maxPlayers: z.number().int().min(2).max(8).default(8),
  maxRounds: z.number().int().min(1).max(10).default(5),
  displayName: z.string().trim().min(2).max(32)
});

function roomCode() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = crypto.getRandomValues(new Uint8Array(7));
  return Array.from(bytes, b => alphabet[b % alphabet.length]).join("");
}

export async function POST(request: Request) {
  const body = CreateRoom.safeParse(await request.json().catch(() => null));
  if (!body.success) return NextResponse.json({ error: "Invalid room details", details: body.error.flatten() }, { status: 400 });

  try {
    const auth = await createSupabaseServerClient();
    const { data: { user } } = await auth.auth.getUser();
    if (!user) return NextResponse.json({ error: "Sign in before creating a room." }, { status: 401 });

    const admin = createSupabaseAdminClient();
    const workspaceId = (await admin.from("workspace_members").select("workspace_id").eq("user_id", user.id).limit(1).maybeSingle()).data?.workspace_id;
    if (!workspaceId) return NextResponse.json({ error: "Your account needs a workspace before creating a room." }, { status: 403 });

    let code = roomCode();
    for (let attempt = 0; attempt < 4; attempt++) {
      const exists = await admin.from("game_rooms").select("id").eq("code", code).maybeSingle();
      if (!exists.data) break;
      code = roomCode();
    }
    const { data: room, error } = await admin.from("game_rooms").insert({
      workspace_id: workspaceId,
      code,
      title: body.data.title,
      host_user_id: user.id,
      status: "lobby",
      phase: "lobby",
      current_round: 1,
      max_rounds: body.data.maxRounds,
      max_players: body.data.maxPlayers,
      objective: body.data.objective,
      objective_type: body.data.objectiveType
    }).select("id,code,title,status,phase,current_round,max_rounds,max_players,objective,objective_type").single();
    if (error || !room) {
      return NextResponse.json({ error: "Could not create room. Confirm the multiplayer SQL migration has been applied." }, { status: 503 });
    }
    const { error: playerError } = await admin.from("game_players").insert({
      room_id: room.id, user_id: user.id, display_name: body.data.displayName, role: "owner", team_id: "alpha", ready: true
    });
    if (playerError) {
      await admin.from("game_rooms").delete().eq("id", room.id);
      return NextResponse.json({ error: "Room creation failed while adding the host." }, { status: 503 });
    }
    await admin.from("game_events").insert({
      room_id: room.id, sequence: 1, event_type: "room_created", actor_user_id: user.id,
      payload: { title: room.title, rulesVersion: "1.0.0" }
    });
    return NextResponse.json({ room }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Server configuration is incomplete. Check Supabase environment variables." }, { status: 503 });
  }
}
