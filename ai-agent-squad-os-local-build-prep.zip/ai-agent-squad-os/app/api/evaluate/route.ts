import { NextResponse } from "next/server";
import { z } from "zod";

/**
 * Safe starter endpoint: validates the evaluation payload but deliberately
 * does not grant a pass or advance persistent state. Add authenticated Supabase
 * access, durable audit writes, and a separately configured evaluator before use.
 */
const EvaluationInput = z.object({
  projectId: z.string().min(1).max(128),
  agentId: z.string().min(1).max(128),
  response: z.string().min(20).max(12000),
  sourceUrls: z.array(z.string().url()).max(20).default([])
});

export async function POST(request: Request) {
  const parsed = EvaluationInput.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid evaluation payload", details: parsed.error.flatten() }, { status: 400 });
  }

  // Fail closed until authentication, tenant checks, independent grading,
  // evidence retrieval, and audit persistence have been implemented.
  return NextResponse.json({
    status: "not_configured",
    passed: false,
    advanced: false,
    message: "Evaluation is not configured. No level was advanced. Configure authenticated persistence and an independent evaluator first."
  }, { status: 503 });
}
