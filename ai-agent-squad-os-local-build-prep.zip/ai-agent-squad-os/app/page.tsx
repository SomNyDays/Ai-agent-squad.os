"use client";

import { useMemo, useState } from "react";
import {
  Activity, ArrowDownRight, ArrowUpRight, BadgeCheck, BarChart3, Bell,
  Bot, BrainCircuit, BriefcaseBusiness, Check, ChevronDown, CircleDollarSign,
  ClipboardCheck, Compass, FileText, FlaskConical, Gauge, Globe, Layers3,
  LockKeyhole, Menu, MessageSquareWarning, MoreHorizontal, Network, Plus,
  Search, Send, ShieldCheck, Sparkles, Target, TrendingUp, Users, X,
  Zap, RefreshCw
} from "lucide-react";

type Agent = {
  id: string; name: string; role: string; boss: string; initials: string;
  color: string; status: "Working" | "Review needed" | "Ready";
  task: string; score: number; level: number;
};

const initialAgents: Agent[] = [
  { id: "research", name: "Research Agent", role: "Market intelligence", boss: "The Market Skeptic", initials: "RA", color: "violet", status: "Working", task: "Mapping overlooked resale and licensing opportunities", score: 92, level: 4 },
  { id: "growth", name: "Growth Agent", role: "Campaign strategy", boss: "The Growth Warden", initials: "GA", color: "blue", status: "Review needed", task: "Testing 3 customer acquisition hypotheses", score: 84, level: 3 },
  { id: "brand", name: "Brand Agent", role: "Brand & sponsorship", boss: "The Brand Guardian", initials: "BA", color: "orange", status: "Working", task: "Building a sponsor-fit shortlist", score: 89, level: 3 },
  { id: "systems", name: "Systems Agent", role: "Product & engineering", boss: "The Systems Breaker", initials: "SA", color: "green", status: "Ready", task: "Validating conversion tracking requirements", score: 95, level: 5 },
  { id: "closer", name: "Deal Closer", role: "Partnerships & contracts", boss: "The Contract Enforcer", initials: "DC", color: "pink", status: "Review needed", task: "Drafting a non-binding partner proposal", score: 81, level: 2 },
  { id: "chief", name: "Chief Intelligence", role: "Cross-agent strategy", boss: "The Executive Auditor", initials: "CI", color: "cyan", status: "Working", task: "Comparing cross-project revenue models", score: 93, level: 4 }
];

const opportunities = [
  { title: "Niche newsletter sponsorship", type: "Sponsorship", confidence: 82, value: "$2.4k–$6k", risk: "Medium", note: "Illustrative estimate · requires audience and advertiser validation" },
  { title: "White-label service package", type: "Partnership", confidence: 74, value: "$4k–$12k", risk: "Medium", note: "Illustrative estimate · validate delivery cost and partner demand" },
  { title: "Unused asset licensing", type: "Licensing", confidence: 68, value: "$800–$3k", risk: "Low", note: "Illustrative estimate · ownership and usage rights must be checked" }
];

const nav = [
  { label: "Overview", icon: Gauge }, { label: "Agent workforce", icon: Bot },
  { label: "Boss gauntlet", icon: ShieldCheck }, { label: "Opportunities", icon: Compass },
  { label: "Portfolio & partners", icon: BriefcaseBusiness }, { label: "Deal room", icon: FileText },
  { label: "Analytics", icon: BarChart3 }, { label: "Shared campaign", icon: Network },
  { label: "System activity", icon: Activity }
];

export default function Home() {
  const [agents, setAgents] = useState(initialAgents);
  const [active, setActive] = useState("Overview");
  const [selectedAgent, setSelectedAgent] = useState("growth");
  const [query, setQuery] = useState("");
  const [toast, setToast] = useState("");
  const [showNew, setShowNew] = useState(false);
  const [newObjective, setNewObjective] = useState("");
  const [bossNotes, setBossNotes] = useState("Show the evidence behind the audience estimate. Include one alternative revenue model and a low-cost validation test.");
  const [source, setSource] = useState("");
  const [evidence, setEvidence] = useState("");
  const [levelState, setLevelState] = useState<Record<string, number>>({});
  const [campaignLive, setCampaignLive] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const filteredAgents = useMemo(() => agents.filter(a => `${a.name} ${a.role} ${a.task}`.toLowerCase().includes(query.toLowerCase())), [agents, query]);
  const focusAgent = agents.find(a => a.id === selectedAgent) ?? agents[0];

  function notify(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 3200);
  }

  function createObjective() {
    if (!newObjective.trim()) return notify("Add an objective before creating a project.");
    notify("Demo project created locally. Connect the database to persist it across sessions.");
    setNewObjective(""); setShowNew(false);
  }

  function submitEvaluation() {
    const nextLevel = (levelState[selectedAgent] ?? focusAgent.level) + 1;
    setLevelState(s => ({ ...s, [selectedAgent]: nextLevel }));
    setAgents(prev => prev.map(a => a.id === selectedAgent ? { ...a, status: "Review needed" } : a));
    notify(`Evaluation submitted for ${focusAgent.name}. Demo state advanced to level ${nextLevel}; no independent pass has been verified.`);
  }

  function chooseNav(label: string) {
    setActive(label);
    setMenuOpen(false);
  }

  return (
    <main className="app-shell">
      <a href="/boss-fight" className="fixed bottom-5 right-5 z-50 rounded-full border border-cyan-300/40 bg-slate-950/95 px-4 py-3 text-sm font-semibold text-cyan-200 shadow-lg shadow-cyan-500/20 hover:bg-cyan-950">⚔ Enter Boss Fight</a>
      <a href="/mission-map" className="fixed bottom-20 right-5 z-50 rounded-full border border-fuchsia-300/40 bg-slate-950/95 px-4 py-3 text-sm font-semibold text-fuchsia-200 shadow-lg shadow-fuchsia-500/20 hover:bg-fuchsia-950">✦ Watch Mission Map</a>

      <aside className={`sidebar ${menuOpen ? "sidebar-open" : ""}`}>
        <div className="brand-lockup">
          <div className="brand-mark"><BrainCircuit size={22} /></div>
          <div><div className="brand-name">SQUAD<span>OS</span></div><div className="brand-caption">AI BUSINESS INTELLIGENCE</div></div>
          <button className="icon-button mobile-close" onClick={() => setMenuOpen(false)} aria-label="Close menu"><X size={18}/></button>
        </div>
        <div className="workspace-switch"><div className="workspace-avatar">S</div><div className="workspace-copy"><strong>Startup workspace</strong><span>Free sandbox</span></div><ChevronDown size={15}/></div>
        <div className="nav-label">WORKSPACE</div>
        <nav>{nav.map(item => {
          const Icon = item.icon;
          return <button key={item.label} onClick={() => chooseNav(item.label)} className={`nav-item ${active === item.label ? "nav-active" : ""}`}><Icon size={17}/><span>{item.label}</span>{item.label === "Boss gauntlet" && <span className="nav-count">2</span>}</button>;
        })}</nav>
        <div className="sidebar-bottom">
          <div className="prime-card"><div className="prime-icon"><Sparkles size={17}/></div><strong>Prime directive</strong><p>Think expansively. Verify rigorously. Act only with authorization.</p><span className="rule-pill"><LockKeyhole size={12}/> GOVERNED AUTONOMY</span></div>
          <div className="sidebar-user"><div className="user-avatar">SO</div><div className="workspace-copy"><strong>Workspace owner</strong><span>Admin access</span></div><MoreHorizontal size={18}/></div>
        </div>
      </aside>

      <section className="main-column">
        <header className="topbar">
          <button className="icon-button menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Open menu"><Menu size={20}/></button>
          <div className="breadcrumbs"><span>Workspace</span><span className="crumb-slash">/</span><strong>{active}</strong></div>
          <div className="topbar-actions"><div className="system-status"><span className="status-dot"></span> Demo environment</div><button className="icon-button" aria-label="Notifications" onClick={() => notify("No new alerts in this demo workspace.")}><Bell size={18}/></button><div className="top-avatar">SO</div></div>
        </header>

        <div className="page-content">
          <div className="welcome-row">
            <div><div className="eyebrow"><span className="eyebrow-line"></span> YOUR INTELLIGENCE WORKFORCE</div><h1>{active === "Overview" ? <>Turn ideas into <span className="gradient-text">measurable growth.</span></> : active}</h1><p className="page-subtitle">{active === "Overview" ? "One coordinated AI workforce. Independent evaluation. Revenue-minded execution." : `Coordinate projects, evaluate evidence, and manage ${active.toLowerCase()} in one governed workspace.`}</p></div>
            <button className="primary-button" onClick={() => setShowNew(true)}><Plus size={17}/> New objective</button>
          </div>

          <div className="notice-banner"><div className="notice-symbol"><ShieldCheck size={18}/></div><div><strong>Prime directive is active</strong><p>Evidence before action. Independent review before advancement. Human approval before consequential commitments.</p></div><button onClick={() => notify("Rule details: no fabricated evidence, unauthorized spending, external commitments, or signatures.")} className="text-action">View rule <span>↗</span></button></div>

          <div className="metric-grid">
            <Metric icon={<Bot size={18}/>} label="Active agents" value="06" trend="4 working now" kind="violet" />
            <Metric icon={<ClipboardCheck size={18}/>} label="Review queue" value="02" trend="Boss review required" kind="orange" />
            <Metric icon={<CircleDollarSign size={18}/>} label="Opportunity value" value="$18.4k" trend="Illustrative pipeline" kind="green" />
            <Metric icon={<Target size={18}/>} label="Evaluation average" value="89.0%" trend="Demo scores · not validated" kind="blue" />
          </div>

          <div className="content-grid">
            <section className="panel workforce-panel">
              <div className="panel-heading"><div><div className="section-kicker">COORDINATED INTELLIGENCE</div><h2>Agent workforce <span className="muted-count">06</span></h2></div><button className="subtle-button" onClick={() => chooseNav("Agent workforce")}>View all <span>→</span></button></div>
              <div className="agent-toolbar"><div className="searchbox"><Search size={15}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search agents or tasks…"/></div><button className="icon-button small-icon" onClick={() => { setAgents(initialAgents); notify("Demo agent data reset."); }} aria-label="Refresh demo agents"><RefreshCw size={15}/></button></div>
              <div className="agent-list">{filteredAgents.slice(0, 6).map(agent => <button key={agent.id} className={`agent-row ${selectedAgent === agent.id ? "agent-row-selected" : ""}`} onClick={() => { setSelectedAgent(agent.id); chooseNav("Agent workforce"); }}><div className={`agent-avatar ${agent.color}`}>{agent.initials}</div><div className="agent-main"><div className="agent-title-row"><strong>{agent.name}</strong><span className={`status-label ${agent.status === "Working" ? "status-working" : agent.status === "Ready" ? "status-ready" : "status-review"}`}><span/> {agent.status}</span></div><span className="agent-role">{agent.role}</span><p>{agent.task}</p><div className="agent-progress"><span style={{width: `${agent.score}%`}}/></div></div><div className="agent-score"><strong>{agent.score}</strong><span>score</span></div></button>)}</div>
              <div className="panel-footer"><span><span className="status-dot"></span> 6 specialist agents configured</span><button className="text-action" onClick={() => chooseNav("Agent workforce")}>Manage workforce ↗</button></div>
            </section>

            <section className="panel gauntlet-panel">
              <div className="panel-heading"><div><div className="section-kicker">QUALITY GATES</div><h2>Boss gauntlet</h2></div><div className="boss-icon"><ShieldCheck size={19}/></div></div>
              <p className="panel-description">Every project earns advancement through evidence, correction, and independent review.</p>
              <div className="level-track">{[1,2,3,4,5].map((level, i) => <div key={level} className={`level-step ${level <= (levelState[selectedAgent] ?? focusAgent.level) ? "level-complete" : ""}`}><div className="level-node">{level <= (levelState[selectedAgent] ?? focusAgent.level) ? <Check size={13}/> : level}</div><span>{["Scope","Evidence","Stress test","Economics","Capstone"][i]}</span></div>)}</div>
              <div className="boss-card"><div className="boss-card-top"><div className="boss-avatar"><ShieldCheck size={18}/></div><div><strong>{focusAgent.boss}</strong><span>Independent evaluator · {focusAgent.name}</span></div><span className="review-badge">LEVEL {(levelState[selectedAgent] ?? focusAgent.level) + 1}</span></div><div className="pitfall"><MessageSquareWarning size={16}/><div><strong>Current challenge</strong><p>{bossNotes}</p></div></div><label className="field-label">Correction / evidence response</label><textarea value={evidence} onChange={e => setEvidence(e.target.value)} placeholder="Explain what changed, cite your evidence, and show the test plan…"/><label className="field-label">Source URL (optional in demo)</label><input className="field-input" value={source} onChange={e => setSource(e.target.value)} placeholder="https://source.example/report"/>
              <button className="primary-button full-button" onClick={submitEvaluation}><Send size={15}/> Submit for boss review</button><p className="microcopy"><LockKeyhole size={12}/> Demo only: submission does not equal a verified pass. Production must evaluate server-side.</p></div>
            </section>
          </div>

          <div className="content-grid lower-grid">
            <section className="panel opportunity-panel">
              <div className="panel-heading"><div><div className="section-kicker">REVENUE INTELLIGENCE</div><h2>Opportunity radar</h2></div><button className="subtle-button" onClick={() => chooseNav("Opportunities")}>Explore all →</button></div>
              <p className="panel-description">Ideas scored for potential value, confidence, risk, and ease of validation.</p>
              <div className="opportunity-list">{opportunities.map((op, i) => <div className="opportunity-row" key={op.title}><div className={`opportunity-symbol op-${i}`}><TrendingUp size={17}/></div><div className="opportunity-copy"><strong>{op.title}</strong><span>{op.type} · {op.risk} risk</span><small>{op.note}</small></div><div className="opportunity-value"><strong>{op.value}</strong><span>{op.confidence}% confidence</span></div><button className="icon-button small-icon" onClick={() => notify(`Saved "${op.title}" to the demo shortlist. Persistent save requires database setup.`)} aria-label={`Save ${op.title}`}><Plus size={16}/></button></div>)}</div>
            </section>
            <section className="panel activity-panel">
              <div className="panel-heading"><div><div className="section-kicker">TRACEABLE OPERATIONS</div><h2>System activity</h2></div><button className="icon-button small-icon" onClick={() => notify("Activity feed refreshed (sample events).")} aria-label="Refresh activity"><RefreshCw size={15}/></button></div>
              <div className="activity-list"><ActivityItem icon={<Search size={15}/>} color="violet" title="Opportunity scan completed" detail="Research Agent · 8 hypotheses generated" time="4 min ago"/><ActivityItem icon={<ShieldCheck size={15}/>} color="orange" title="Boss requested a correction" detail="Growth Warden · evidence gap detected" time="12 min ago"/><ActivityItem icon={<FlaskConical size={15}/>} color="green" title="Experiment proposal drafted" detail="Systems Agent · conversion tracking" time="21 min ago"/><ActivityItem icon={<LockKeyhole size={15}/>} color="blue" title="Approval gate enforced" detail="Deal Closer · external send not authorized" time="32 min ago"/></div>
              <div className="audit-note"><LockKeyhole size={14}/><span>Illustrative events only. Production audit logs are append-only and stored server-side.</span></div>
            </section>
          </div>

          <section className="panel intelligence-panel">
            <div className="intelligence-copy"><div className="intelligence-icon"><BrainCircuit size={22}/></div><div className="section-kicker">OUT-OF-THE-BOX INTELLIGENCE</div><h2>Think wider. Test smarter. Learn faster.</h2><p>Agents generate competing strategies, borrow models across industries, challenge assumptions, and run the smallest safe experiment before scaling.</p><button className="subtle-button" onClick={() => chooseNav("Shared campaign")}>Explore shared intelligence <span>→</span></button></div>
            <div className="intelligence-cards"><div><Sparkles size={17}/><strong>Parallel ideas</strong><span>Distinct strategies, not simple variations.</span></div><div><MessageSquareWarning size={17}/><strong>Adversarial review</strong><span>A dedicated critic tries to disprove the plan.</span></div><div><FlaskConical size={17}/><strong>Low-cost tests</strong><span>Validate assumptions before scaling.</span></div><div><Layers3 size={17}/><strong>Persistent learning</strong><span>Capture outcomes and reuse proven tactics.</span></div></div>
          </section>

          <footer className="page-footer"><span>© Squad OS · Governed AI workforce</span><span><span className="footer-dot"/> Sandbox mode <span className="footer-divider">·</span> No live providers connected</span></footer>
        </div>
      </section>

      {showNew && <div className="modal-backdrop" onClick={() => setShowNew(false)}><section className="modal" onClick={e => e.stopPropagation()}><div className="modal-head"><div><div className="section-kicker">NEW WORK ITEM</div><h2>Define an objective</h2></div><button className="icon-button" onClick={() => setShowNew(false)} aria-label="Close modal"><X size={18}/></button></div><p className="panel-description">The Chief Intelligence Agent will split the objective into research, strategy, evaluation, and approval tasks.</p><label className="field-label">Business objective</label><textarea value={newObjective} onChange={e => setNewObjective(e.target.value)} placeholder="Example: Find three profitable sponsorship opportunities for our audience…" /><div className="modal-actions"><button className="subtle-button" onClick={() => setShowNew(false)}>Cancel</button><button className="primary-button" onClick={createObjective}><Plus size={15}/> Create objective</button></div><p className="microcopy">Demo mode stores this only in the current interface. Database persistence is a deployment step.</p></section></div>}
      {toast && <div className="toast"><BadgeCheck size={17}/>{toast}<button onClick={() => setToast("")} aria-label="Dismiss"><X size={14}/></button></div>}
    </main>
  );
}

function Metric({ icon, label, value, trend, kind }: { icon: React.ReactNode; label: string; value: string; trend: string; kind: string }) {
  return <div className="metric-card"><div className={`metric-icon ${kind}`}>{icon}</div><div className="metric-label">{label}</div><div className="metric-value">{value}</div><div className="metric-trend"><span>{trend}</span></div></div>;
}
function ActivityItem({ icon, color, title, detail, time }: { icon: React.ReactNode; color: string; title: string; detail: string; time: string }) {
  return <div className="activity-item"><div className={`activity-icon ${color}`}>{icon}</div><div className="activity-copy"><strong>{title}</strong><span>{detail}</span><small>{time}</small></div></div>;
}
